webpackJsonp([3],{

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const performFix = (fn) => {
    chrome.storage.sync.get('ifSaveUnAuthPic', (items) => {
        fn(items['ifSaveUnAuthPic']).then((saveUnAuthPicEnabled) => {
            if (saveUnAuthPicEnabled) {
                const allowContextMenu = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                const allowMouseDown = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                const allowSelectStart = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                const allowCut = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                const allowCopy = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                const allowPaste = e => {
                    e.stopImmediatePropagation();
                    e.returnValue = true;
                    return true;
                };
                document.addEventListener('contextmenu', allowContextMenu, true);
                document.addEventListener('mousedown', allowMouseDown, true);
                document.addEventListener('selectstart', allowSelectStart, true);
                document.addEventListener('cut', allowCut, true);
                document.addEventListener('copy', allowCopy, true);
                document.addEventListener('paste', allowPaste, true);
            }
            chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
                const message = request;
                switch (message.type) {
                    case 'C_SAVE':
                        const imgmsg = request;
                        const selectInfo = imgmsg.info;
                        const imgSrc = selectInfo.srcUrl;
                        console.log(`info: ${JSON.stringify(imgmsg.info)}`);
                        console.log(`tab: ${JSON.stringify(imgmsg.tab)}`);
                        if (typeof imgSrc === 'string') {
                            let durl, name;
                            if (isImg(imgSrc)) {
                                durl = imgSrc;
                            }
                            const urlTest1 = imgSrc.substring(0, imgSrc.lastIndexOf('/'));
                            if (isImg(urlTest1)) {
                                durl = urlTest1;
                            }
                            const urlTest2 = imgSrc.substring(0, imgSrc.lastIndexOf('?'));
                            if (isImg(urlTest2)) {
                                durl = urlTest2;
                            }
                            const urlTest3 = imgSrc.substring(0, imgSrc.lastIndexOf('!'));
                            if (isImg(urlTest3)) {
                                durl = urlTest3;
                            }
                            const urlTest4 = imgSrc.substring(0, imgSrc.lastIndexOf('#'));
                            if (isImg(urlTest4)) {
                                durl = urlTest4;
                            }
                            if (durl !== undefined) {
                                if (durl.indexOf('pbs.twimg.com') > 0) {
                                    durl = durl.concat(':orig');
                                    name = durl.substring(durl.lastIndexOf('/') + 1, durl.lastIndexOf(':'));
                                }
                                const response = { durl, name };
                                sendResponse(response);
                            }
                        }
                        break;
                    default: break;
                }
            });
        });
    });
};
performFix((saveUnAuthPicEnabled) => __awaiter(this, void 0, void 0, function* () { return saveUnAuthPicEnabled; }));
const imgReg = /\.(gif|jpg|jpeg|png|apng|webp|bmp|tiff|svg|exif|wmf)$/;
const isImg = (imgurl) => {
    const suffix = imgurl.substring(imgurl.lastIndexOf('.'), imgurl.length);
    return imgReg.test(suffix.toLowerCase());
};


/***/ })

},[2]);