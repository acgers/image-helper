webpackJsonp([4],[
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

chrome.contextMenus.create({
    id: 'm_pic_bcy_origin',
    title: chrome.i18n.getMessage('saveOrgBtn'),
    enabled: true,
    checked: false,
    contexts: ['image', 'link']
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'm_pic_bcy_origin') {
        chrome.tabs.query({ active: true, currentWindow: true }, (result) => {
            result.map((v, i) => {
                if (typeof v.id === 'number' && tab !== undefined) {
                    const message = { type: 'C_SAVE', info, tab };
                    chrome.tabs.sendMessage(v.id, message, (response) => {
                        const resp = response;
                        const durl = resp.durl;
                        const name = resp.name;
                        if (name !== undefined) {
                            chrome.downloads.download({ url: durl, filename: name }, (downloadId) => {
                                console.log(`download ${downloadId}: succeed.`);
                            });
                        }
                        else {
                            chrome.downloads.download({ url: durl }, (downloadId) => {
                                console.log(`download ${downloadId}: succeed.`);
                            });
                        }
                    });
                }
            });
        });
    }
});


/***/ })
],[1]);